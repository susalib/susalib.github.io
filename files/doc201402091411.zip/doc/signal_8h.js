var signal_8h =
[
    [ "conv", "signal_8h.html#ga707ea9c4e31a7e12240810398839702c", null ],
    [ "convmtx", "signal_8h.html#gad6302ba3c2df8ed4b2c75424533ca7ea", null ],
    [ "downsample", "signal_8h.html#ga49ef6645c02814b45e20f3f2b718735a", null ],
    [ "filter", "signal_8h.html#ga579c5c271af925864f41ae93804e2cc1", null ],
    [ "toeplitz", "signal_8h.html#ga7b47e0d036cde53215703a0f44139226", null ],
    [ "upsample", "signal_8h.html#ga111a21d2de4647895aaf5d16c1bb3d1f", null ]
];