var group___statistics =
[
    [ "mean", "group___statistics.html#ga57070f1511bbdb0f4f1fab31ff30c663", null ],
    [ "stdv", "group___statistics.html#gadaf8649ff9671cefe53bf20531bb4644", null ],
    [ "var", "group___statistics.html#gac1daea6155db963604fdfe8b3059bb4f", null ]
];