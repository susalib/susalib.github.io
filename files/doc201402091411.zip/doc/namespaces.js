var namespaces =
[
    [ "susa", "namespacesusa.html", null ]
];