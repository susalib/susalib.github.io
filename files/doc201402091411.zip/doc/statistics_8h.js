var statistics_8h =
[
    [ "mean", "statistics_8h.html#ga57070f1511bbdb0f4f1fab31ff30c663", null ],
    [ "stdv", "statistics_8h.html#gadaf8649ff9671cefe53bf20531bb4644", null ],
    [ "var", "statistics_8h.html#gac1daea6155db963604fdfe8b3059bb4f", null ]
];