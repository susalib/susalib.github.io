var linalg_8h =
[
    [ "concat", "linalg_8h.html#ga2bd6ca54aab751ca587995ae81d78af6", null ],
    [ "det", "linalg_8h.html#ga7ecbc54fea7c4d52cf8659696ee413ad", null ],
    [ "fliplr", "linalg_8h.html#gae1944c6cd1f15fff28f053bf0917fbed", null ],
    [ "flipud", "linalg_8h.html#ga03b8a83eaf36154cac2649fd96cdde0b", null ],
    [ "mult", "linalg_8h.html#ga15ed3c420e77ae05ce3e881b7d4d2f71", null ],
    [ "transpose", "linalg_8h.html#gaf7f519c75e153de65826ea692d0eec63", null ]
];