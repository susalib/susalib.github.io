var classsusa_1_1_r_r_cosine =
[
    [ "RRCosine", "classsusa_1_1_r_r_cosine.html#a6b70ed7ab3fc945f4b3724efb9900ccc", null ],
    [ "RRCosine", "classsusa_1_1_r_r_cosine.html#ad02780f6162d3b02040170221d9823f6", null ],
    [ "get", "classsusa_1_1_r_r_cosine.html#aa163305b50b1aab9bdcac3c9bb77efed", null ]
];