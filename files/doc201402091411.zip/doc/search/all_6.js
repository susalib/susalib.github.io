var searchData=
[
  ['fft',['fft',['../classsusa_1_1fft.html',1,'susa']]],
  ['fft_2eh',['fft.h',['../fft_8h.html',1,'']]],
  ['filter',['filter',['../group___signal.html#ga579c5c271af925864f41ae93804e2cc1',1,'susa']]],
  ['fliplr',['fliplr',['../group___l_a_l_g.html#gae1944c6cd1f15fff28f053bf0917fbed',1,'susa']]],
  ['flipud',['flipud',['../group___l_a_l_g.html#ga03b8a83eaf36154cac2649fd96cdde0b',1,'susa']]]
];
