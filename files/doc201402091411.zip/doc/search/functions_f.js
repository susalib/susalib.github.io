var searchData=
[
  ['select_5fleast',['select_least',['../group___search.html#ga258ee4ce481ef8555bfe271dd72f84da',1,'susa']]],
  ['select_5flimited_5fleast',['select_limited_least',['../group___search.html#gac1d8910bad9532de0a554f86498ccac0',1,'susa']]],
  ['select_5fmost',['select_most',['../namespacesusa.html#af72f07744da229e17e25d0b053156a17',1,'susa']]],
  ['set_5fall',['set_all',['../classsusa_1_1matrix.html#af53d43723649ad1e5ddd308a914ae2b2',1,'susa::matrix']]],
  ['set_5fgenerator',['set_generator',['../classsusa_1_1convolutional__codec.html#a19ebec7feb4c51e3ac2fb8062073b4fb',1,'susa::convolutional_codec']]],
  ['set_5finternal_5fstate',['set_internal_state',['../classsusa_1_1convolutional__codec.html#a7df1d14a668f46fbc9685cbe77b5b885',1,'susa::convolutional_codec']]],
  ['shrink',['shrink',['../classsusa_1_1matrix.html#a7693761c849dedf827fae876067c3f7b',1,'susa::matrix']]],
  ['sign',['sign',['../group___math.html#ga8364235fd56c786f0865adbf7174f19f',1,'susa::sign(const matrix&lt; T &gt; &amp;mat_arg)'],['../namespacesusa.html#a40886bfc1acda12c31db753339b3d6ff',1,'susa::sign(T T_arg)']]],
  ['size',['size',['../classsusa_1_1matrix.html#a4c258c016ceeb6ad2421d5bef9993378',1,'susa::matrix']]],
  ['stdv',['stdv',['../group___statistics.html#gadaf8649ff9671cefe53bf20531bb4644',1,'susa']]],
  ['sum',['sum',['../group___math.html#ga1032f16f39c53dc30bf706fed46db9e6',1,'susa']]],
  ['svd',['svd',['../group___l_a_l_g.html#ga5618d2898bc20980abead67e4b76209e',1,'susa']]]
];
