var searchData=
[
  ['channel',['channel',['../classsusa_1_1channel.html',1,'susa']]],
  ['convolutional_5fcodec',['convolutional_codec',['../classsusa_1_1convolutional__codec.html',1,'susa']]]
];
