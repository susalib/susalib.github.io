var searchData=
[
  ['var',['var',['../group___statistics.html#gac1daea6155db963604fdfe8b3059bb4f',1,'susa']]]
];
