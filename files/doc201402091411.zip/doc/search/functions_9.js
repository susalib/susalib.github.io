var searchData=
[
  ['mag',['mag',['../group___math.html#ga954491fe18a8bdb0a47d211026019edf',1,'susa']]],
  ['main',['main',['../bcjr__bpsk__cc75_8cpp.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;bcjr_bpsk_cc75.cpp'],['../qam__ser__gaussian_8cpp.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;qam_ser_gaussian.cpp']]],
  ['matrix',['matrix',['../classsusa_1_1matrix.html#a9a3ff6c2d3f72b539fbaaf81eb9d15f6',1,'susa::matrix::matrix()'],['../classsusa_1_1matrix.html#abbb23453da577d9e2785310ab48fbaca',1,'susa::matrix::matrix(unsigned int uint_rows, unsigned int uint_cols, T Tinitial)'],['../classsusa_1_1matrix.html#a9ff53345adbbba22b1a4b74d35254e5b',1,'susa::matrix::matrix(unsigned int uint_rows, unsigned int uint_cols)'],['../classsusa_1_1matrix.html#a693b4b4ac2661369a7edb1f0a9e1b863',1,'susa::matrix::matrix(const matrix&lt; T &gt; &amp;mat_arg)'],['../classsusa_1_1matrix.html#a8106fee08974e74ac289c89161a35db9',1,'susa::matrix::matrix(std::string str_string)']]],
  ['max',['max',['../group___math.html#ga212cf40145ea00f67dbe64200ed3ac83',1,'susa']]],
  ['mean',['mean',['../group___math.html#ga9c99b114165c1ac287ea0b2b1b637249',1,'susa::mean(matrix&lt; T &gt; &amp;mat_arg)'],['../group___statistics.html#ga57070f1511bbdb0f4f1fab31ff30c663',1,'susa::mean(std::vector&lt; T &gt; vec_arg)']]],
  ['mid',['mid',['../classsusa_1_1matrix.html#a8f876a3c864632366178eed37752630c',1,'susa::matrix']]],
  ['min',['min',['../group___math.html#ga8cab62e2d3748cd3f0777ba5adf21d49',1,'susa']]],
  ['mod',['mod',['../group___math.html#gaedb2665d3cdfee07ecfcabf7927fac7b',1,'susa']]],
  ['modulate_5fbits',['modulate_bits',['../classsusa_1_1qam.html#a3bf9ad29ce75bcc745057443f5304fad',1,'susa::qam']]],
  ['mt',['mt',['../classsusa_1_1mt.html#ac2bb71e8fa01e2d4cc7adb54ecc3537b',1,'susa::mt::mt(void)'],['../classsusa_1_1mt.html#a1a06954751c393a052417cf662af562e',1,'susa::mt::mt(unsigned long ul_seed)']]],
  ['mult',['mult',['../group___l_a_l_g.html#ga15ed3c420e77ae05ce3e881b7d4d2f71',1,'susa']]]
];
