var searchData=
[
  ['basic_20mathematics',['Basic Mathematics',['../group___math.html',1,'']]]
];
