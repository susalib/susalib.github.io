var searchData=
[
  ['ncdf',['ncdf',['../group___math.html#gaf47bb40de68073e310c9e4e213d73045',1,'susa']]],
  ['next_5foutput',['next_output',['../classsusa_1_1channel.html#a2fd756d152c3e2a060d0784b02063a12',1,'susa::channel::next_output()'],['../classsusa_1_1convolutional__codec.html#accc6efb73ecc0510f3306939c817be93',1,'susa::convolutional_codec::next_output(unsigned int uint_state, bool b_input)'],['../classsusa_1_1convolutional__codec.html#ab5632f875e8d04299755da7087218a1d',1,'susa::convolutional_codec::next_output(bool b_input)']]],
  ['next_5fstate',['next_state',['../classsusa_1_1channel.html#a393cd8ed2a8e0895f117501dec388c76',1,'susa::channel::next_state()'],['../classsusa_1_1convolutional__codec.html#aca09c2290910e4c50fd170e1baa44cd3',1,'susa::convolutional_codec::next_state(unsigned int uint_state, bool b_input)'],['../classsusa_1_1convolutional__codec.html#ab03456f0689c3ae6d0cb8c2c757aba48',1,'susa::convolutional_codec::next_state(bool b_input)']]],
  ['no_5fcols',['no_cols',['../classsusa_1_1matrix.html#a435c813410282ff8a88a0a084ab6aa46',1,'susa::matrix']]],
  ['no_5frows',['no_rows',['../classsusa_1_1matrix.html#a4d85b607ca46cbc0300be3dca73b5d72',1,'susa::matrix']]],
  ['nonuniform',['nonUniform',['../classsusa_1_1rng.html#a927ddc17a038e9c7833d53ab9a3a5879',1,'susa::rng']]],
  ['norm',['norm',['../group___math.html#gad4fc9d7d373bf6a6f54a87723fd5fd9a',1,'susa']]]
];
