var searchData=
[
  ['transpose',['transpose',['../classsusa_1_1matrix.html#ac76029f7bdbad93d8f8b90f41199fefc',1,'susa::matrix']]]
];
