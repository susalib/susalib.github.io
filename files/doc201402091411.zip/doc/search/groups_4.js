var searchData=
[
  ['search',['Search',['../group___search.html',1,'']]],
  ['signal_20processing',['Signal Processing',['../group___signal.html',1,'']]],
  ['statistics',['Statistics',['../group___statistics.html',1,'']]]
];
