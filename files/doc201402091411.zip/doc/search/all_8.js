var searchData=
[
  ['imag',['imag',['../group___math.html#gaa29d21df52ff4af88e1533aa46ab617a',1,'susa']]],
  ['init',['init',['../classsusa_1_1rng.html#aa9f65eba8d5e38c673f6a130f2c65c78',1,'susa::rng']]],
  ['init_5fby_5farray',['init_by_array',['../classsusa_1_1mt.html#a545107dc65cecd429e607b61dee599f2',1,'susa::mt']]],
  ['init_5fgenrand',['init_genrand',['../classsusa_1_1mt.html#a71255b65c23962a23daf4ce8e3849c4f',1,'susa::mt']]]
];
