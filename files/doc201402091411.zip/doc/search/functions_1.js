var searchData=
[
  ['bpsk',['bpsk',['../group___communications.html#gafceb7c80b23927207b4f7b570538cc3e',1,'susa']]],
  ['build_5ftrellis',['build_trellis',['../classsusa_1_1convolutional__codec.html#a63579fd1250dc55693d154682b362490',1,'susa::convolutional_codec']]]
];
