var searchData=
[
  ['left',['left',['../classsusa_1_1matrix.html#ae4f584e6e561aff59b7faab78c43f79b',1,'susa::matrix']]],
  ['log',['log',['../group___math.html#gaac4f9868100fd279f1162e87a0a2b651',1,'susa']]]
];
