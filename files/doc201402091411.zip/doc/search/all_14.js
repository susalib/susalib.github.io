var searchData=
[
  ['zero_5fstate',['zero_state',['../classsusa_1_1convolutional__codec.html#ae9fb47921148791c04797cba3c7e5b9b',1,'susa::convolutional_codec']]]
];
