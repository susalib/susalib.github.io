var searchData=
[
  ['encode',['encode',['../classsusa_1_1convolutional__codec.html#a70ac0f392c1fe63f107dc997fd6441ee',1,'susa::convolutional_codec']]],
  ['encode_5fisi',['encode_isi',['../classsusa_1_1channel.html#ab4498ee0a85a950b757a53eef1defb58',1,'susa::channel']]]
];
