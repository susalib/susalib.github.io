var base_8h =
[
    [ "abs", "base_8h.html#ga43d1e2b1c6ac871dad9148832435c647", null ],
    [ "conj", "base_8h.html#gaeaa799bd98dbba81c59ca84b7c16a33e", null ],
    [ "diff", "base_8h.html#gabee7bb1653d52e3d579f6f38cf451b50", null ],
    [ "imag", "base_8h.html#gaa29d21df52ff4af88e1533aa46ab617a", null ],
    [ "log", "base_8h.html#gaac4f9868100fd279f1162e87a0a2b651", null ],
    [ "mag", "base_8h.html#ga954491fe18a8bdb0a47d211026019edf", null ],
    [ "max", "base_8h.html#ga212cf40145ea00f67dbe64200ed3ac83", null ],
    [ "mean", "base_8h.html#ga9c99b114165c1ac287ea0b2b1b637249", null ],
    [ "min", "base_8h.html#ga8cab62e2d3748cd3f0777ba5adf21d49", null ],
    [ "mod", "base_8h.html#gaedb2665d3cdfee07ecfcabf7927fac7b", null ],
    [ "ncdf", "base_8h.html#gaf47bb40de68073e310c9e4e213d73045", null ],
    [ "norm", "base_8h.html#gad4fc9d7d373bf6a6f54a87723fd5fd9a", null ],
    [ "pow", "base_8h.html#ga42c1cee5a81d5efd83d8984a095c3ee3", null ],
    [ "pow", "base_8h.html#gace35e26872f5ad983087ae1132ef4904", null ],
    [ "qfunc", "base_8h.html#gae7ceef7ab9f0f65939ab282a630f6e27", null ],
    [ "real", "base_8h.html#ga28a8444902e58ab97787c6a04e53053b", null ],
    [ "sign", "base_8h.html#ga8364235fd56c786f0865adbf7174f19f", null ],
    [ "sign", "base_8h.html#a40886bfc1acda12c31db753339b3d6ff", null ],
    [ "sum", "base_8h.html#ga1032f16f39c53dc30bf706fed46db9e6", null ]
];