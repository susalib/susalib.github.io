var group___math =
[
    [ "abs", "group___math.html#ga43d1e2b1c6ac871dad9148832435c647", null ],
    [ "conj", "group___math.html#gaeaa799bd98dbba81c59ca84b7c16a33e", null ],
    [ "diff", "group___math.html#gabee7bb1653d52e3d579f6f38cf451b50", null ],
    [ "imag", "group___math.html#gaa29d21df52ff4af88e1533aa46ab617a", null ],
    [ "log", "group___math.html#gaac4f9868100fd279f1162e87a0a2b651", null ],
    [ "mag", "group___math.html#ga954491fe18a8bdb0a47d211026019edf", null ],
    [ "max", "group___math.html#ga212cf40145ea00f67dbe64200ed3ac83", null ],
    [ "mean", "group___math.html#ga9c99b114165c1ac287ea0b2b1b637249", null ],
    [ "min", "group___math.html#ga8cab62e2d3748cd3f0777ba5adf21d49", null ],
    [ "mod", "group___math.html#gaedb2665d3cdfee07ecfcabf7927fac7b", null ],
    [ "ncdf", "group___math.html#gaf47bb40de68073e310c9e4e213d73045", null ],
    [ "norm", "group___math.html#gad4fc9d7d373bf6a6f54a87723fd5fd9a", null ],
    [ "pow", "group___math.html#ga42c1cee5a81d5efd83d8984a095c3ee3", null ],
    [ "pow", "group___math.html#gace35e26872f5ad983087ae1132ef4904", null ],
    [ "qfunc", "group___math.html#gae7ceef7ab9f0f65939ab282a630f6e27", null ],
    [ "real", "group___math.html#ga28a8444902e58ab97787c6a04e53053b", null ],
    [ "sign", "group___math.html#ga8364235fd56c786f0865adbf7174f19f", null ],
    [ "sum", "group___math.html#ga1032f16f39c53dc30bf706fed46db9e6", null ]
];