var namespacesusa =
[
    [ "channel", "classsusa_1_1channel.html", "classsusa_1_1channel" ],
    [ "convolutional_codec", "classsusa_1_1convolutional__codec.html", "classsusa_1_1convolutional__codec" ],
    [ "fft", "classsusa_1_1fft.html", "classsusa_1_1fft" ],
    [ "matrix", "classsusa_1_1matrix.html", "classsusa_1_1matrix" ],
    [ "qam", "classsusa_1_1qam.html", "classsusa_1_1qam" ],
    [ "mt", "classsusa_1_1mt.html", "classsusa_1_1mt" ],
    [ "rng", "classsusa_1_1rng.html", "classsusa_1_1rng" ],
    [ "RRCosine", "classsusa_1_1_r_r_cosine.html", "classsusa_1_1_r_r_cosine" ]
];