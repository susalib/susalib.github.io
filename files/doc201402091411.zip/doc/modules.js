var modules =
[
    [ "Basic Mathematics", "group___math.html", "group___math" ],
    [ "Communications", "group___communications.html", "group___communications" ],
    [ "Linear Algebra", "group___l_a_l_g.html", "group___l_a_l_g" ],
    [ "Random Number Generator", "group___r_n_g.html", "group___r_n_g" ],
    [ "Search", "group___search.html", "group___search" ],
    [ "Signal Processing", "group___signal.html", "group___signal" ],
    [ "Statistics", "group___statistics.html", "group___statistics" ],
    [ "Utility", "group___utility.html", "group___utility" ]
];