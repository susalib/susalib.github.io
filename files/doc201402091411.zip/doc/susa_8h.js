var susa_8h =
[
    [ "_SUSA_TERMINATE_ON_ERROR", "susa_8h.html#a3bf82dbe69b543b2b901d6ccba9ce95a", null ],
    [ "PI", "susa_8h.html#a598a3330b3c21701223ee0ca14316eca", null ]
];