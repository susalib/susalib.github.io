var base_8cpp =
[
    [ "mod", "base_8cpp.html#gaedb2665d3cdfee07ecfcabf7927fac7b", null ],
    [ "ncdf", "base_8cpp.html#gaf47bb40de68073e310c9e4e213d73045", null ],
    [ "pow", "base_8cpp.html#ga42c1cee5a81d5efd83d8984a095c3ee3", null ],
    [ "pow", "base_8cpp.html#gace35e26872f5ad983087ae1132ef4904", null ],
    [ "qfunc", "base_8cpp.html#gae7ceef7ab9f0f65939ab282a630f6e27", null ]
];